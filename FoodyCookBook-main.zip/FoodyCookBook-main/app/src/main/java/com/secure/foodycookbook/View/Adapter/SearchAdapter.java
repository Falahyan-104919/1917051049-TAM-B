package com.secure.foodycookbook.View.Adapter;

public class SearchAdapter {

}
